//
//  File.swift
//  
//
//  Created by devin_sun on 2022/8/9.
//

import Fluent
import Vapor

final class TodoSettings: Model, Content {
    static let schema = "todos_setting"
    
    @ID(key: .id)
    var id: UUID?
    
    @Field(key: "name")
    var name: String
    
    @Field(key: "content")
    var content: String
    
    @Parent(key: "todo_id")
    var todo: Todo
    
    init() { }
    
    init(id: UUID? = nil, name: String, todoID: UUID) {
        self.id = id
        self.name = name
        self.$todo.id = todoID
    }
}
