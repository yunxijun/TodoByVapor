import Fluent
import Vapor

final class Todo: Model, Content {
    static let schema = "todos"
    
    @ID(key: .id)
    var id: UUID?
    
    @Field(key: "name")
    var name: String
    
    @Children(for: \.$todo)
    var settings: [TodoSettings]
    
    @Parent(key: "user_id")
    var user: User
    
    init() { }
    
    init(id: UUID? = nil, name: String, userId: UUID) {
        self.id = id
        self.name = name
        self.$user.id = userId
    }
}
