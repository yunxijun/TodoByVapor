//
//  File.swift
//  
//
//  Created by devin_sun on 2022/8/13.
//

import Fluent
import Vapor

final class User: Model, Content {
    static let schema = "users"
    
    @ID(key: .id)
    var id: UUID?
    
    @Field(key: "name")
    var name: String
    
    @Field(key: "image_name")
    var image_name: String

    @Field(key: "password_hash")
    var password_hash: String
    
    @Children(for: \.$user)
    var tokens: [UserToken]
    
    @Children(for: \.$user)
    var todo: [Todo]
    
    init() { }
    
    init(id: UUID? = nil, name: String, image_name:String, password_hash: String) {
        self.id = id
        self.name = name
        self.image_name = image_name
        self.password_hash = password_hash
    }
}

extension User: ModelAuthenticatable {
    static let usernameKey = \User.$name
    static let passwordHashKey = \User.$password_hash

    func verify(password: String) throws -> Bool {
        try Bcrypt.verify(password, created: self.password_hash)
    }
}

extension User {
    func generateToken() throws -> UserToken {
        try .init(
            value: [UInt8].random(count: 16).base64,
            userID: self.requireID()
        )
    }
}

