//
//  File.swift
//  
//
//  Created by devin_sun on 2022/8/9.
//
import Fluent

struct CreateTodoSettings: AsyncMigration {
    func prepare(on database: Database) async throws {
        try await database.schema("todos_setting")
            .id()
            .field("name", .string, .required)
            .field("content", .string, .required)
            .field("todo_id", .uuid, .references("todos", "id"))
            .create()
    }

    func revert(on database: Database) async throws {
        try await database.schema("todo_setting").delete()
    }
}
