import Fluent
import Vapor

func routes(_ app: Application) throws {
    
//    grouped.post("upload") { request async throws -> HTTPStatus in
//        let img = request.formData?["img"];
//        let imgPart = img?.part;
//        let imgBody = imgPart?.body;
//
//        if let imgDat = imgBody{
//            let data = NSData.init(bytes: imgDat, length: (imgBody?.count)!);
//            try?data.write(to: URL.init(fileURLWithPath: "/Users/xiaocangkeji/Desktop/011.jpg"), options: NSData.WritingOptions.atomic);
//        } else{
//            throw Abort.badRequest
//        }
//        return .noContent
//    }
    
    let grouped = app.grouped(User.authenticator()).grouped(User.guardMiddleware())
    
    grouped.get("loginWithPassword") { req async throws -> UserToken in
        let user = try req.auth.require(User.self)
        let token = try user.generateToken()
        try await token.save(on: req.db)
        return token
    }

    
    let newGroup =  app.grouped(UserToken.authenticator()).grouped(UserToken.guardMiddleware())
    
    
    newGroup.get("loginWithToken") { req async throws -> UserToken in
        let user = try req.auth.require(User.self)
        let token = try user.generateToken()
        try await token.save(on: req.db)
        return token
    }
    
    
    
    try app.register(collection: UserController())
    try app.register(collection: TodoController())
    try app.register(collection: TodoSettingsController())

}
