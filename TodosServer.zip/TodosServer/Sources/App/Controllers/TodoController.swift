import Fluent
import Vapor

// DTO
struct PatchTodo: Decodable {
    var name: String?
}

// DTO
struct DTOTodo: Content, Decodable {
    var name: String?
    var id: UUID?
    var settings: [DTOSetting]
}


struct DTOUser: Content, Decodable {
    var name: String?
    var id: UUID?
    var password_hash: String?
    var todo: [Todo]
    var tokens: [UserToken]
}

struct TodoController: RouteCollection {
    func boot(routes: RoutesBuilder) throws {
        let todos = routes.grouped("todos")
        todos.get(use: index)
        todos.post(use: create)
        todos.group(":todoID") { todo in
            todo.delete(use: delete)
        }
        todos.group("upload") { todo in
            todo.post(use: uplaod)
        }
        
        todos.group(":todoID") { todo in
            todo.patch(use: modify)
        }
        todos.group(":todoID") { todo in
            todo.get(use: getFromID)
        }
        todos.group("todo",":todoID") { todo in
            todo.get(use: getFromParentID)
        }
    }
    
    func uplaod(req: Request) async throws -> HTTPStatus {
        print("")
//        let img = req.formData?["img"]
//        let imgPart = img?.pa
//        let imgBody = imgPart?.body
//
//        if let imgDat = imgBody{
//            let data = NSData.init(bytes: imgDat, length: (imgBody?.count)!);
//            try?data.write(to: URL.init(fileURLWithPath: "/Users/xiaocangkeji/Desktop/011.jpg"), options: NSData.WritingOptions.atomic);
//        } else{
//            throw Abort.badRequest
//        }
        return .noContent
    }

    func index(req: Request) async throws -> [Todo] {
        try await Todo.query(on: req.db).with(\.$settings).all()
    }

    
    func getFromParentID(req: Request) async throws -> [Todo] {
        guard let parentId = req.parameters.get("todoID") else {
            throw Abort(.notFound)
        }
        let response = try await req.client.get("http://127.0.0.1:8080/users/\(parentId)")
        let parentUser = try response.content.decode(DTOUser.self)
        return parentUser.todo
    }
    
    
    func getFromID(req: Request) async throws -> Todo {
        guard let todo = try await Todo.find(req.parameters.get("todoID"), on: req.db) else {
            throw Abort(.notFound)
        }
        guard let todoComplete = try await Todo.query(on: req.db).filter(\.$id == todo.id!).with(\.$settings).first() else {
            throw Abort(.notFound)
        }
        return todoComplete
    }
    
    // modify the data
    func modify(req: Request) async throws -> Todo {
        guard let todo = try await Todo.find(req.parameters.get("todoID"), on: req.db) else {
            throw Abort(.notFound)
        }
        let patch = try req.content.decode(PatchTodo.self)
        if let name = patch.name {
            todo.name = name
        }
        try await todo.save(on: req.db)
        return todo
    }

    func create(req: Request) async throws -> Todo {
        let todo = try req.content.decode(Todo.self)
        try await todo.save(on: req.db)
        return todo
    }

    func delete(req: Request) async throws -> HTTPStatus {
        guard let todo = try await Todo.find(req.parameters.get("todoID"), on: req.db) else {
            throw Abort(.notFound)
        }
        let response = try await req.client.get("http://127.0.0.1:8080/settings/\(todo.id!.uuidString)")
        let settings = try response.content.decode([DTOSetting].self)
        for item in settings {
            let _ = try await req.client.delete("http://127.0.0.1:8080/settings/\(item.id.uuidString)")
        }
        try await todo.delete(on: req.db)
        return .noContent
    }
    
}
