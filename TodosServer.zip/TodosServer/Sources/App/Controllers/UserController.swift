//
//  File.swift
//  
//
//  Created by devin_sun on 2022/8/13.
//

import Foundation
import Vapor
import Fluent

struct DTOCreateUser: Content {
    var name: String
    var password: String
    var confirmPassword: String
}


struct DTOPatchUser: Content {
    var name: String?
    var image: String?
    var password: String?
}

extension DTOCreateUser: Validatable {
    static func validations(_ validations: inout Validations) {
        validations.add("name", as: String.self, is: !.empty)
        validations.add("password", as: String.self, is: !.count(8...))
    }
}
struct UserController: RouteCollection {
    func boot(routes: RoutesBuilder) throws {
        let users = routes.grouped("users")
        users.get(use: index)
        users.post(use: create)
        users.group(":userID") { user in
            user.delete(use: delete)
        }
        users.group(":userID") { user in
            user.patch(use: modify)
        }
        users.group(":userID") { user in
            user.get(use: getFromID)
        }
    }

    func index(req: Request) async throws -> [User] {
        try await User.query(on: req.db).with(\.$todo).with(\.$tokens).all()
    }

    
    func getFromID(req: Request) async throws -> User {
        guard let user = try await User.find(req.parameters.get("userID"), on: req.db) else {
            throw Abort(.notFound)
        }
        guard let todoComplete = try await User.query(on: req.db).filter(\.$id == user.id!).with(\.$todo).with(\.$tokens).first() else {
            throw Abort(.notFound)
        }
        return todoComplete
    }
    
//     modify the data
    func modify(req: Request) async throws -> User {
        guard let user = try await User.find(req.parameters.get("userID"), on: req.db) else {
            throw Abort(.notFound)
        }
        let patch = try req.content.decode(DTOPatchUser.self)
        if let name = patch.name {
            user.name = name
        }
        
        if let image_name = patch.image {
            user.image_name = image_name
        }
        try await user.save(on: req.db)
        return user
    }

    func create(req: Request) async throws -> UserToken {
        try DTOCreateUser.validate(content: req)
        let createUser = try req.content.decode(DTOCreateUser.self)
        guard createUser.password == createUser.confirmPassword else {
            throw Abort(.badRequest, reason: "Passwords did not match")
        }
        let user = try User(
            name: createUser.name,
            image_name: "",
            password_hash: Bcrypt.hash(createUser.password)
        )
        try await user.save(on: req.db)
        let token = try user.generateToken()
        try await token.save(on: req.db)
        return token
    }

    func delete(req: Request) async throws -> HTTPStatus {
        guard let user = try await User.find(req.parameters.get("userID"), on: req.db) else {
            throw Abort(.notFound)
        }
//        let response = try await req.client.get("http://127.0.0.1:8080/settings/\(User.id!.uuidString)")
//        let settings = try response.content.decode([DTOSetting].self)
//        for item in settings {
//            let _ = try await req.client.delete("http://127.0.0.1:8080/settings/\(item.id.uuidString)")
//        }
        try await user.delete(on: req.db)
        return .noContent
    }
    
}

