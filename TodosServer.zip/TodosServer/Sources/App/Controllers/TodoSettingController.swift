//
//  File.swift
//  
//
//  Created by devin_sun on 2022/8/9.
//

import Fluent
import Vapor


// DTO

struct PatchSetting: Decodable {
    var name: String?
    var content: String?
}

struct DTOSetting: Content, Decodable {
    var name: String?
    var content: String?
    var id: UUID
    var todo: TodoID
}

struct TodoID: Content, Decodable {
    var id: UUID
}

struct TodoSettingsController: RouteCollection {
    func boot(routes: RoutesBuilder) throws {
        let todoSettings = routes.grouped("settings")
        todoSettings.get(use: index)
        todoSettings.post(use: create)
        todoSettings.group(":todoSettingID") { todo in
            todo.delete(use: delete)
        }
        todoSettings.group(":todoSettingID") { todo in
            todo.patch(use: modify)
        }
        todoSettings.group(":todoSettingID") { todo in
            todo.get(use: getFromParentID)
        }
        
    }
    
    // get all data with relations  //zi
    func index(req: Request) async throws -> [TodoSettings] {
        guard let id = try req.query.get(String?.self, at: "setting_id") else {
            return try await TodoSettings.query(on: req.db).with(\.$todo).all()
        }
        guard let uuid: UUID = UUID(uuidString: id) else {
            throw Abort(.badRequest)
        }
        let res = try await TodoSettings.query(on: req.db).filter(\.$id == uuid).all()
        return res
    }
    
    func getFromParentID(req: Request) async throws -> [DTOSetting] {
        guard let parentID = req.parameters.get("todoSettingID") else {
            throw Abort(.notFound)
        }
        let response = try await req.client.get("http://127.0.0.1:8080/todos/\(parentID)")
        let parentTodo = try response.content.decode(DTOTodo.self)
        return parentTodo.settings
    }

    // create model data
    func create(req: Request) async throws -> TodoSettings {
        let todoSetting = try req.content.decode(TodoSettings.self)
        try await todoSetting.save(on: req.db)
        return todoSetting
    }
    
    
    // modify the data
    func modify(req: Request) async throws -> TodoSettings {
        guard let todoSetting = try await TodoSettings.find(req.parameters.get("todoSettingID"), on: req.db) else {
            throw Abort(.notFound)
        }
        let patch = try req.content.decode(PatchSetting.self)
        if let name = patch.name {
            todoSetting.name = name
        }
        if let content = patch.content {
            todoSetting.content = content
        }
        try await todoSetting.save(on: req.db)
        return todoSetting
    }

    // delete select data
    func delete(req: Request) async throws -> HTTPStatus {
        guard let todoSetting = try await TodoSettings.find(req.parameters.get("todoSettingID"), on: req.db) else {
            throw Abort(.notFound)
        }
        try await todoSetting.delete(on: req.db)
        return .noContent
    }
    
    
}
